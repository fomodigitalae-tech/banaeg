import express from 'express';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import mysql from 'mysql2/promise';
import jwt from 'jsonwebtoken';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const distDir = path.join(rootDir, 'dist');
const app = express();
const port = Number(process.env.PORT || 3000);
const sessionSecret = process.env.MANUS_JWT_SECRET || process.env.MANUS_PROJECT_ID || 'smartwatch-local-session';

let pool;
let schemaPromise;

function getDatabasePool() {
  if (pool) return pool;
  const raw = process.env.DATABASE_URL || process.env.DRIZZLE_DATABASE_URL;
  if (!raw) throw new Error('DATABASE_URL is not configured');
  const url = new URL(raw);
  pool = mysql.createPool({
    host: url.hostname,
    port: Number(url.port || 3306),
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: decodeURIComponent(url.pathname.replace(/^\//, '')),
    ssl: { rejectUnauthorized: true },
    waitForConnections: true,
    connectionLimit: 5,
    charset: 'utf8mb4',
  });
  return pool;
}

async function ensureSchema() {
  if (schemaPromise) return schemaPromise;
  schemaPromise = (async () => {
    const db = getDatabasePool();
    await db.execute(`
      CREATE TABLE IF NOT EXISTS orders (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        customer_name VARCHAR(160) NOT NULL,
        middle_name VARCHAR(160) NOT NULL,
        phone VARCHAR(40) NOT NULL,
        national_id VARCHAR(32) NOT NULL,
        watch_name VARCHAR(80) NOT NULL,
        watch_color VARCHAR(80) NOT NULL,
        status ENUM('new','reviewed','completed') NOT NULL DEFAULT 'new',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_orders_created_at (created_at),
        INDEX idx_orders_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
  })();
  return schemaPromise;
}

function parseCookies(req) {
  const header = req.headers.cookie || '';
  return Object.fromEntries(header.split(';').filter(Boolean).map((part) => {
    const index = part.indexOf('=');
    return [part.slice(0, index).trim(), decodeURIComponent(part.slice(index + 1).trim())];
  }));
}

function serializeCookie(name, value, { maxAge = 0, httpOnly = true } = {}) {
  const parts = [`${name}=${encodeURIComponent(value)}`, 'Path=/', 'SameSite=None', 'Secure'];
  if (httpOnly) parts.push('HttpOnly');
  if (maxAge) parts.push(`Max-Age=${maxAge}`);
  else parts.push('Max-Age=0');
  return parts.join('; ');
}

function setCookie(res, name, value, options) {
  res.append('Set-Cookie', serializeCookie(name, value, options));
}

function clearCookie(res, name) {
  setCookie(res, name, '', { maxAge: 0 });
}

function publicOrigin(req) {
  const proto = String(req.headers['x-forwarded-proto'] || (req.secure ? 'https' : 'http')).split(',')[0].trim();
  const host = String(req.headers['x-forwarded-host'] || req.headers.host).split(',')[0].trim();
  return `${proto}://${host}`;
}

function verifySession(token) {
  try {
    const payload = jwt.verify(token, sessionSecret, { algorithms: ['HS256'] });
    if (payload.appId && process.env.MANUS_PROJECT_ID && payload.appId !== process.env.MANUS_PROJECT_ID) return null;
    return payload;
  } catch {
    return null;
  }
}

function currentUser(req) {
  const cookies = parseCookies(req);
  const token = cookies.smartwatch_admin_session || cookies.webdev_app_session;
  if (!token) return null;
  return verifySession(token);
}

function requireAdmin(req, res, next) {
  const user = currentUser(req);
  if (!user?.openId && !user?.sub) return res.status(401).json({ error: 'authentication_required' });
  req.user = user;
  next();
}

app.use(express.json({ limit: '64kb' }));

app.get('/api/health', (_req, res) => res.status(200).json({ ok: true }));

app.get('/api/auth/login', (req, res) => {
  const portal = process.env.MANUS_OAUTH_PORTAL_URL;
  const projectId = process.env.MANUS_PROJECT_ID;
  if (!portal || !projectId) return res.status(503).send('تسجيل الدخول غير متاح حاليًا.');
  const nonce = crypto.randomBytes(24).toString('base64url');
  const redirectUri = `${publicOrigin(req)}/api/auth/callback`;
  const state = Buffer.from(JSON.stringify({ redirectUri, nonce })).toString('base64url');
  setCookie(res, 'smartwatch_oauth_state', nonce, { maxAge: 600 });
  const query = new URLSearchParams({ appId: projectId, redirectUri, state, responseType: 'code' });
  res.redirect(`${portal.replace(/\/$/, '')}/app-auth?${query.toString()}`);
});

app.get('/api/auth/callback', async (req, res) => {
  try {
    const cookies = parseCookies(req);
    const state = JSON.parse(Buffer.from(String(req.query.state || ''), 'base64url').toString('utf8'));
    if (!state.nonce || state.nonce !== cookies.smartwatch_oauth_state || !req.query.code) return res.status(400).send('تعذر التحقق من جلسة الدخول.');
    const api = process.env.MANUS_OAUTH_API_URL;
    const exchangeResponse = await fetch(`${api}/webdev.v1.WebDevAuthPublicService/ExchangeToken`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ clientId: process.env.MANUS_PROJECT_ID, grantType: 'authorization_code', code: req.query.code, redirectUri: state.redirectUri }),
    });
    if (!exchangeResponse.ok) throw new Error('oauth_exchange_failed');
    const exchange = await exchangeResponse.json();
    const infoResponse = await fetch(`${api}/webdev.v1.WebDevAuthPublicService/GetUserInfo`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ accessToken: exchange.accessToken }),
    });
    if (!infoResponse.ok) throw new Error('oauth_identity_failed');
    const info = await infoResponse.json();
    const user = { appId: process.env.MANUS_PROJECT_ID, openId: info.openId, email: info.email, name: info.name };
    const session = jwt.sign(user, sessionSecret, { algorithm: 'HS256', expiresIn: '7d' });
    setCookie(res, 'smartwatch_admin_session', session, { maxAge: 604800 });
    clearCookie(res, 'smartwatch_oauth_state');
    res.redirect('/dashboard');
  } catch (error) {
    console.error('OAuth callback failed:', error.message);
    res.status(401).send('تعذر تسجيل الدخول. حاول مرة أخرى.');
  }
});

app.get('/api/auth/logout', (_req, res) => {
  clearCookie(res, 'smartwatch_admin_session');
  res.redirect('/');
});

app.get('/api/me', requireAdmin, (req, res) => res.json({ user: { name: req.user.name || '', email: req.user.email || '' } }));

app.post('/api/orders', async (req, res) => {
  const { name, middle, phone, national, watchName, watchColor } = req.body || {};
  if (!name || !middle || !phone || !national || String(national).length !== 14 || !watchName || !watchColor) {
    return res.status(400).json({ error: 'invalid_order' });
  }
  try {
    await ensureSchema();
    const db = getDatabasePool();
    const [result] = await db.execute(
      'INSERT INTO orders (customer_name, middle_name, phone, national_id, watch_name, watch_color) VALUES (?, ?, ?, ?, ?, ?)',
      [String(name).trim(), String(middle).trim(), String(phone).trim(), String(national).trim(), String(watchName).trim(), String(watchColor).trim()],
    );
    res.status(201).json({ ok: true, id: result.insertId });
  } catch (error) {
    console.error('Order create failed:', error.message);
    res.status(500).json({ error: 'order_storage_failed' });
  }
});

app.get('/api/orders', requireAdmin, async (_req, res) => {
  try {
    await ensureSchema();
    const [rows] = await getDatabasePool().query(`
      SELECT id, customer_name AS customerName, middle_name AS middleName, phone, national_id AS nationalId,
        watch_name AS watchName, watch_color AS watchColor, status, created_at AS createdAt
      FROM orders ORDER BY created_at DESC LIMIT 500
    `);
    res.json({ orders: rows });
  } catch (error) {
    console.error('Orders read failed:', error.message);
    res.status(500).json({ error: 'orders_read_failed' });
  }
});

app.patch('/api/orders/:id', requireAdmin, async (req, res) => {
  const status = String(req.body?.status || '');
  if (!['new', 'reviewed', 'completed'].includes(status)) return res.status(400).json({ error: 'invalid_status' });
  try {
    await ensureSchema();
    await getDatabasePool().execute('UPDATE orders SET status = ? WHERE id = ?', [status, req.params.id]);
    res.json({ ok: true });
  } catch (error) {
    console.error('Order update failed:', error.message);
    res.status(500).json({ error: 'order_update_failed' });
  }
});

app.use(express.static(distDir, { extensions: ['html'] }));
app.get('/dashboard', (_req, res) => res.sendFile(path.join(distDir, 'dashboard.html')));

app.listen(port, '0.0.0.0', async () => {
  try {
    await ensureSchema();
    console.log(`Smartwatch server listening on ${port}`);
  } catch (error) {
    console.error('Database initialization failed:', error.message);
  }
});
